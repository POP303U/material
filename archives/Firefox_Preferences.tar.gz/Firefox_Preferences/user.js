/* Enable userChrome.css and userContent.css */
user_pref("toolkit.legacyUserProfileCustomizations.stylesheets", true);
user_pref("browser.tabs.tabmanager.enabled", false);

/* Disable about:config warning ***/
user_pref("browser.aboutConfig.showWarning", false);
